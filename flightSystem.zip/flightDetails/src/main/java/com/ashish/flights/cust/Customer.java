package com.ashish.flights.cust;

import com.ashish.flights.FlightService;
import com.ashish.flights.pojo.FlightDetails;

public class Customer {
	public static void main(String[] args) {
		FlightService service = new FlightService();
		service.addFlight(new FlightDetails(1, "Indigo", null, null, 0, 0, 0));
		for(FlightDetails fd: service.getAllFlight()) {
        	System.out.println(fd);
        }
		service.updateFlightByDestination(1, "Indigo");
		for(FlightDetails fd: service.getAllFlight()) {
        	System.out.println(fd);
        }
	}
}
