package com.ashish.flights;

import java.util.ArrayList;

import com.ashish.flights.pojo.FlightDetails;

public class FlightService {
	ArrayList<FlightDetails> flightList;
	
	public FlightService() {
		flightList = new ArrayList<FlightDetails>();
	}
	
	public FlightService(int size) {
		flightList = new ArrayList<FlightDetails>(size);
	}
	
	public void addFlight(FlightDetails flightDetails) {
		flightList.add(flightDetails);
	}
	
	public ArrayList<FlightDetails> removeFlightByFlightNo(int flightNo){
		flightList.remove(flightNo);
		return flightList;
	}
	
	public ArrayList<FlightDetails> updateFlightByDestination(int flightNo, String destination){
		for(FlightDetails fd: flightList) {
			if(fd.getFlightNo()==flightNo) {
				fd.setDestination(destination);
				return flightList;
			}
		}
		throw new RuntimeException("Flight not found");
	}
	
	public ArrayList<FlightDetails> updateFlightBySource(int flightNo, String source){
		for(FlightDetails fd: flightList) {
			if(fd.getFlightNo()==flightNo) {
				fd.setSource(source);
				return flightList;
			}
		}
		throw new RuntimeException("Flight not found");
	}
	
	public ArrayList<FlightDetails> updateFlightByDepartureTime(int flightNo, int departureTime){
		for(FlightDetails fd: flightList) {
			if(fd.getFlightNo()==flightNo) {
				fd.setDepartureTime(departureTime);
				return flightList;
			}
		}
		throw new RuntimeException("Flight not found");
	}
	
	public ArrayList<FlightDetails> updateFlightByArrivalTime(int flightNo, int arrivalTime){
		for(FlightDetails fd: flightList) {
			if(fd.getFlightNo()==flightNo) {
				fd.setArrivalTime(arrivalTime);
				return flightList;
			}
		}
		throw new RuntimeException("Flight not found");
	}
	
	public ArrayList<FlightDetails> getAllFlight() {
		return flightList;
	}
	
	
}
