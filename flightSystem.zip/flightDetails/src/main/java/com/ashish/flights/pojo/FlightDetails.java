package com.ashish.flights.pojo;

import java.util.Date;

/**
 * 
 * @author agupt139
 * @since 04-10-2018
 * 
 */
public class FlightDetails {
	
	int flightNo;
	String flightName;
	String destination;
	String source;
	double price;
	int departureTime;
	int arrivalTime;
	Date routeTime;
	static int autoFlightNoGen;
	
	{
		flightNo=++autoFlightNoGen;
	}
	
	public FlightDetails(int flightNo, String flightName, String destination, String source, double price,
			int departureTime, int arrivalTime) {
		super();
		this.flightNo = flightNo;
		this.flightName = flightName;
		this.destination = destination;
		this.source = source;
		this.price = price;
		this.departureTime = departureTime;
		this.arrivalTime = arrivalTime;
	}
	
	public Date getRouteTime() {
		return routeTime;
	}

	public void setRouteTime(Date routeTime) {
		this.routeTime = routeTime;
	}

	public int getFlightNo() {
		return flightNo;
	}
	public String getFlightName() {
		return flightName;
	}
	public void setFlightName(String flightName) {
		this.flightName = flightName;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public int getDepartureTime() {
		return departureTime;
	}
	public void setDepartureTime(int departureTime) {
		this.departureTime = departureTime;
	}
	public int getArrivalTime() {
		return arrivalTime;
	}
	public void setArrivalTime(int arrivalTime) {
		this.arrivalTime = arrivalTime;
	}

	@Override
	public String toString() {
		return "FlightDetails [flightNo=" + flightNo + ", flightName=" + flightName + ", destination=" + destination
				+ ", source=" + source + ", price=" + price + ", departureTime=" + departureTime + ", arrivalTime="
				+ arrivalTime + ", routeTime=" + routeTime + "]";
	}
	
}
