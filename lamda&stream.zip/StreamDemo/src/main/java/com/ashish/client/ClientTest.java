package com.ashish.client;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

public class ClientTest {

	public static void main(String[] args) {

		String arr[] = new String[]{"A","B","C"};
		Stream<String> stream= Arrays.stream(arr);
		stream.forEach(System.out::println);
		System.out.println("------");
		Stream<String> of = Stream.of("a","b","c");
		of.forEach(System.out::println);
		System.out.println("------");
		List<String> names= new ArrayList<>();
		names.add("Raman");
		names.add("Raghav");
		names.add("2.0");
		Stream<String> stream2 = names.stream();
		stream2.forEach(System.out::println);
	}

}
