package com.ashish.lambda;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Function;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ReferenceToAnInstanceMethodInLambda {

	public static void main(String[] args) {

		List<Person> person=new ArrayList<Person>();
		person.add(new Person("Tanya",23));
		person.add(new Person("Sohail",21));
		person.add(new Person("Nikhil",22));
		
		List<String> personList=ReferenceToAnInstanceMethodInLambda.getPersonName(person,Person::getName);
		personList.forEach(System.out::println);
		
		
		System.out.println("-----------------");
		person.forEach(System.out::println);
		System.out.println("-----------------");		
		ExecutorService executorService = Executors.newSingleThreadExecutor();
		
		Runnable command = ReferenceToAnInstanceMethodInLambda::myRun;
		executorService.execute(command);
		System.out.println("-----------------");		
		List<Integer> numbers = Arrays.asList(4,9,25,36,100);
		numbers.forEach(System.out::println);
		System.out.println("-----------------");
		
		List<Double> findSquareRoots = ReferenceToAnInstanceMethodInLambda.findSquareRoot(numbers);
		findSquareRoots.forEach(System.out::println);
		
		
	}

	private static List<Double> findSquareRoot(List<Integer> numbers) {
		
		List<Double> results = new ArrayList<>();
		numbers.forEach(x->results.add(Math.sqrt(x)));
		
		return results;
	}

	private static List<String> getPersonName(List<Person> person, Function<Person,String> f) {
		
		List<String> result=new ArrayList<String>();
		person.forEach(n ->result.add(f.apply(n)));
		
		return result;
	}
	
	public static void myRun() {
		System.out.println("My task is running");
	}
	
	}


